STOCK CALCULATOR - ANDROID PROJECT

यह Android Studio में खुलने वाला पूरा प्रोजेक्ट है। इसमें आपकी दी हुई HTML calculator फाइल ऐप के अंदर रखी गई है और WebView के जरिए ऑफलाइन चलती है।

APK बनाने के चरण:
1. कंप्यूटर पर Android Studio इंस्टॉल करें।
2. ZIP फाइल को Extract करें।
3. Android Studio खोलें और "Open" चुनें।
4. Extract किया हुआ StockCalculator फोल्डर चुनें।
5. Gradle Sync पूरा होने दें। जरूरत पड़ने पर Android SDK Platform 35 इंस्टॉल करें।
6. ऊपर मेन्यू में Build > Build Bundle(s) / APK(s) > Build APK(s) चुनें।
7. Build पूरा होने पर "locate" पर क्लिक करें। APK app/build/outputs/apk/debug/app-debug.apk में मिलेगा।
8. APK अपने Android फोन में भेजें, खोलें और अनुमति मिलने पर "Install unknown apps" की अनुमति देकर इंस्टॉल करें।

जरूरी:
- APK बनाने के लिए कंप्यूटर और Android Studio चाहिए।
- इस प्रोजेक्ट में इंटरनेट permission नहीं है; calculator ऑफलाइन चलता है।
- अभी मूल HTML के हिसाब से गणना होती है। यह HTML खुद entries को बंद करने के बाद सेव नहीं करती।
- App icon Android का default icon है; चाहें तो बाद में custom icon जोड़ा जा सकता है।
